package app.resource;

public enum ResourceState {
    RELEASED, WANTED, HELD
}
